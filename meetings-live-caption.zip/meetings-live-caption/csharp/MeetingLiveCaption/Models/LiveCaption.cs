﻿using Newtonsoft.Json;

namespace MeetingLiveCaption.Models
{
    public class LiveCaption
    {
        public string CaptionText { get; set; }
        public string CartUrl { get; set; }
    }
}
